package com.example.proovjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProovJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProovJavaApplication.class, args);
    }

}
