package com.example.proovjava;

import com.example.proovjava.entity.User;
import com.example.proovjava.repository.UserRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void run(String... args) throws Exception {
        // Load the JSON file
        ObjectMapper objectMapper = new ObjectMapper();
        InputStream inputStream = new ClassPathResource("users.json").getInputStream();

        // Read JSON into list of User objects
        List<User> users = objectMapper.readValue(inputStream, new TypeReference<List<User>>() {});

        // Save users and their cars to the database
        userRepository.saveAll(users);
    }
}
